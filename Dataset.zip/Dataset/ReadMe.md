# Title of Dataset
---
Set of data from the Picotaur characterization.

## Description of the data and file structure

Walking, turning, and loadcarrying results contain the robot’s position data with respect to time.
Leg characterization result contains the leg tip’s position with respect to time. Except ‘Phase_change.txt’, the data were produced from high speed camera measurements. Therefore, the recorded frame rate and playback frame rate should be compared before using the data.
Actuation frequency//recorded frame rate//playback frame rate
1//250//20
2//250//20
3//250//20
5//250//20
10//250//20
20//500//20
30//500//20
50//1000//20
75//3000//20
100//6400//20
125//6400//20
150//6400//20
200//6400//20
300//6400//20
400//6400//20
500//10000//20


Powerconsumption contains the time series of the voltage across the known resistor (220 kOhm) and the applied voltage to the actuators.
Dataset_smallscale_legged_robot.xlsx contains the velocity, size, and CoT data from previously reported small legged robots.
